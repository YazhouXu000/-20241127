# import pandas as pd
# import numpy as np
# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.pipeline import Pipeline
# from sklearn.ensemble import RandomForestRegressor
# import xgboost as xgb
# from sklearn.impute import SimpleImputer
# from sklearn.metrics import mean_squared_error
# import plotly.graph_objects as go
#
# # 数据准备（路径和特征处理保持不变）
# file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
# data = pd.read_excel(file_path)
# data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
# features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
# target_24 = data['Amount_24']
# target_48 = data['Amount_48h']
# target_72 = data['Amount_72h']
# target_96 = data['Amount_96h']
# numeric_features = features.select_dtypes(include=['number']).columns
# categorical_features = features.select_dtypes(include=['object']).columns
#
# preprocessor = ColumnTransformer(
#     transformers=[
#         ('num', Pipeline(steps=[
#             ('imputer', SimpleImputer(strategy='mean')),
#             ('scaler', StandardScaler())
#         ]), numeric_features),
#         ('cat', Pipeline(steps=[
#             ('imputer', SimpleImputer(strategy='most_frequent')),
#             ('onehot', OneHotEncoder())
#         ]), categorical_features)
#     ])
#
# # 定义模型列表
# models = {
#     'Random Forest': RandomForestRegressor(random_state=42),
#     'XGBoost': xgb.XGBRegressor(random_state=42)
# }
#
#
# # 评估模型函数
# def train_and_evaluate_model(pipeline, features, target):
#     X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
#     pipeline.fit(X_train, y_train)
#     y_train_pred = pipeline.predict(X_train)
#     y_test_pred = pipeline.predict(X_test)
#     train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
#     test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
#     return {
#         'train_rmse': train_rmse,
#         'test_rmse': test_rmse
#     }
#
#
# targets = {
#     '24 Hour Amount': target_24,
#     '48 Hour Amount': target_48,
#     '72 Hour Amount': target_72,
#     '96 Hour Amount': target_96
# }
#
# # 存储各个模型的评估结果
# all_results = {}
#
# for model_name, model in models.items():
#     pipeline = Pipeline(steps=[
#         ('preprocessor', preprocessor),
#         ('regressor', model)
#     ])
#
#     for target_name, target in targets.items():
#         results = train_and_evaluate_model(pipeline, features, target)
#         all_results[f'{model_name}_{target_name}'] = results
#
#
# # 绘制桑基图，不显示模型名称，分开显示每个模型
# def plot_sankey(model_name, all_results):
#     sankey_data = {
#         'source': [],
#         'target': [],
#         'value': []
#     }
#
#     # 添加颜色定义
#     colors = {
#         'Overestimation': 'rgba(31, 119, 180, 0.8)',
#         'Underestimation': 'rgba(255, 127, 14, 0.8)',
#         '24 Hour Amount': 'rgba(188, 189, 34, 0.8)',
#         '48 Hour Amount': 'rgba(23, 190, 207, 0.8)',
#         '72 Hour Amount': 'rgba(214, 39, 40, 0.8)',
#         '96 Hour Amount': 'rgba(44, 160, 44, 0.8)',
#         'Dataset Size': 'rgba(140, 86, 75, 0.8)',
#         'Feature Limitation': 'rgba(148, 103, 189, 0.8)',
#         'Data Missing': 'rgba(227, 119, 194, 0.8)',
#         'Data Heterogeneity': 'rgba(31, 119, 180, 0.8)'
#     }
#
#     # 填充桑基图的数据，只显示选定的模型
#     for model_target, result in all_results.items():
#         if model_name not in model_target:
#             continue  # 只显示指定模型的结果
#
#         train_rmse = result['train_rmse']
#         test_rmse = result['test_rmse']
#         error_type_train = 'Overestimation' if train_rmse > test_rmse else 'Underestimation'
#         error_type_test = 'Overestimation' if test_rmse > train_rmse else 'Underestimation'
#         _, target_name = model_target.split('_')
#
#         # 从错误类型直接连接到目标变量
#         sankey_data['source'].extend([error_type_train, error_type_test])
#         sankey_data['target'].extend([target_name, target_name])
#         sankey_data['value'].extend([train_rmse, test_rmse])
#
#         # 从目标变量到数据集性质的连接，使用虚拟的权重值来增加第三列的高度
#         distribution_value = max(train_rmse, test_rmse)  # 选择较大的误差值作为分配基准
#         sankey_data['source'].extend([target_name, target_name, target_name, target_name])
#         sankey_data['target'].extend(['Dataset Size', 'Feature Limitation', 'Data Missing', 'Data Heterogeneity'])
#         sankey_data['value'].extend([distribution_value * 0.25] * 4)  # 将误差值等分分配给各个属性
#
#     # 获取所有节点的唯一值
#     all_nodes = list(set(sankey_data['source'] + sankey_data['target']))
#     node_indices = {node: idx for idx, node in enumerate(all_nodes)}
#     sankey_data['source'] = [node_indices[node] for node in sankey_data['source']]
#     sankey_data['target'] = [node_indices[node] for node in sankey_data['target']]
#     node_colors = [colors.get(node, 'rgba(0,0,0,0.5)') for node in all_nodes]
#
#     # 创建桑基图
#     fig = go.Figure(go.Sankey(
#         node=dict(
#             pad=15,
#             thickness=20,
#             line=dict(color="black", width=0.5),
#             label=all_nodes,
#             color=node_colors
#         ),
#         link=dict(
#             source=sankey_data['source'],
#             target=sankey_data['target'],
#             value=sankey_data['value'],
#             color=[node_colors[source] for source in sankey_data['source']]
#         )
#     ))
#
#     fig.update_layout(
#         title_text=f"{model_name} Model Error and Dataset Properties Flow",
#         font=dict(size=14),
#         title_font_size=20,
#         margin=dict(l=20, r=20, t=40, b=20)
#     )
#     fig.show()
#
#
# # 绘制 `Random Forest` 和 `XGBoost` 的桑基图
# plot_sankey('Random Forest', all_results)
# plot_sankey('XGBoost', all_results)


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error

# 数据准备（路径和特征处理保持不变）
file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
data = pd.read_excel(file_path)
data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
target_24 = data['Amount_24']
target_48 = data['Amount_48h']
target_72 = data['Amount_72h']
target_96 = data['Amount_96h']
numeric_features = features.select_dtypes(include=['number']).columns
categorical_features = features.select_dtypes(include=['object']).columns

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ]), numeric_features),
        ('cat', Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder())
        ]), categorical_features)
    ])

# 定义模型列表
models = {
    'Random Forest': RandomForestRegressor(random_state=42),
    'XGBoost': xgb.XGBRegressor(random_state=42)
}


# 评估模型函数
def train_and_evaluate_model(pipeline, features, target):
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
    pipeline.fit(X_train, y_train)
    y_train_pred = pipeline.predict(X_train)
    y_test_pred = pipeline.predict(X_test)
    train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    return {
        'train_rmse': train_rmse,
        'test_rmse': test_rmse
    }


targets = {
    '24 Hour Amount': target_24,
    '48 Hour Amount': target_48,
    '72 Hour Amount': target_72,
    '96 Hour Amount': target_96
}

# 存储各个模型的评估结果
all_results = {}

for model_name, model in models.items():
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', model)
    ])

    for target_name, target in targets.items():
        results = train_and_evaluate_model(pipeline, features, target)
        all_results[f'{model_name}_{target_name}'] = results


# 导出数据以便在 Origin 中作图
def export_data_for_origin(model_name, all_results, output_file):
    export_data = {
        'Source': [],
        'Target': [],
        'Value': []
    }

    # 填充数据，只显示选定的模型
    for model_target, result in all_results.items():
        if model_name not in model_target:
            continue  # 只显示指定模型的结果

        train_rmse = result['train_rmse']
        test_rmse = result['test_rmse']
        total_rmse = train_rmse + test_rmse
        train_proportion = train_rmse / total_rmse if total_rmse > 0 else 0
        test_proportion = test_rmse / total_rmse if total_rmse > 0 else 0

        error_type_train = 'Overestimation' if train_rmse > test_rmse else 'Underestimation'
        error_type_test = 'Overestimation' if test_rmse > train_rmse else 'Underestimation'
        _, target_name = model_target.split('_')

        # 从错误类型直接连接到目标变量，使用比例作为流量
        export_data['Source'].extend([error_type_train, error_type_test])
        export_data['Target'].extend([target_name, target_name])
        export_data['Value'].extend([train_proportion, test_proportion])

        # 从目标变量到数据集性质的连接，均匀分配流量到每个数据集属性
        export_data['Source'].extend([target_name, target_name, target_name, target_name])
        export_data['Target'].extend(['Dataset Size', 'Feature Limitation', 'Data Missing', 'Data Heterogeneity'])
        export_data['Value'].extend([train_proportion * 0.25] * 4)  # 将总比例等分到四个数据集属性

    # 转换为 DataFrame 并导出为 CSV 文件
    export_df = pd.DataFrame(export_data)
    export_df.to_csv(output_file, index=False)
    print(f"Data exported to {output_file}")


# 导出 `Random Forest` 和 `XGBoost` 的数据
export_data_for_origin('Random Forest', all_results, 'Random_Forest_Sankey_Data.csv')
export_data_for_origin('XGBoost', all_results, 'XGBoost_Sankey_Data.csv')
