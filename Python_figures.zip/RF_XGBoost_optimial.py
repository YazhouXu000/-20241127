# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn.model_selection import train_test_split, cross_val_predict
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.pipeline import Pipeline
# from sklearn.impute import SimpleImputer
# from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
# from sklearn.ensemble import RandomForestRegressor
# import xgboost as xgb
# from sklearn.feature_selection import RFE
# import math
# from sklearn.model_selection import KFold
#
# # 读取数据
# file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
# data = pd.read_excel(file_path)
#
# # 丢弃目标变量中含有缺失值的行
# data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
#
# # 选择特征和目标变量
# features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
# targets = {
#     '24h': data['Amount_24'],
#     '48h': data['Amount_48h'],
#     '72h': data['Amount_72h'],
#     '96h': data['Amount_96h']
# }
#
# # 分离数值型和非数值型特征
# numeric_features = features.select_dtypes(include=['number']).columns
# categorical_features = features.select_dtypes(include=['object']).columns
#
# # 创建预处理管道
# preprocessor = ColumnTransformer(
#     transformers=[('num', Pipeline(steps=[('imputer', SimpleImputer(strategy='mean')),  # 填补数值特征中的缺失值
#                                           ('scaler', StandardScaler())]), numeric_features),
#                   ('cat', Pipeline(steps=[('imputer', SimpleImputer(strategy='most_frequent')),  # 填补分类特征中的缺失值
#                                           ('onehot', OneHotEncoder(handle_unknown='ignore'))]), categorical_features)
#                   ])
#
# # 评估模型性能指标
# def evaluate_model_performance(y_true, y_pred):
#     mse = mean_squared_error(y_true, y_pred)
#     rmse = math.sqrt(mse)
#     mae = mean_absolute_error(y_true, y_pred)
#     r2 = r2_score(y_true, y_pred)
#     return mse, rmse, mae, r2
#
# # 函数：训练加权投票模型（RandomForest + XGBoost），评估模型性能并可视化
# def train_weighted_voting_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=0.5, xgb_weight=0.5, num_features=None):
#     # 特征选择 - 使用RFE进行特征选择
#     if num_features is not None:
#         rfe_selector = RFE(estimator=RandomForestRegressor(random_state=42), n_features_to_select=num_features)
#         X_train_selected = rfe_selector.fit_transform(X_train_transformed, y_train)
#         X_test_selected = rfe_selector.transform(X_test_transformed)
#     else:
#         X_train_selected = X_train_transformed
#         X_test_selected = X_test_transformed
#
#     # 定义XGBoost和Random Forest模型
#     xgboost_model = xgb.XGBRegressor(random_state=42)
#     rf_model = RandomForestRegressor(random_state=42)
#
#     # 训练XGBoost模型
#     xgboost_model.fit(X_train_selected, y_train)
#
#     # 训练Random Forest模型
#     rf_model.fit(X_train_selected, y_train)
#
#     # 预测
#     y_train_pred_rf = rf_model.predict(X_train_selected)
#     y_test_pred_rf = rf_model.predict(X_test_selected)
#
#     y_train_pred_xgb = xgboost_model.predict(X_train_selected)
#     y_test_pred_xgb = xgboost_model.predict(X_test_selected)
#
#     # 加权投票合并预测结果
#     y_train_pred_weighted = rf_weight * y_train_pred_rf + xgb_weight * y_train_pred_xgb
#     y_test_pred_weighted = rf_weight * y_test_pred_rf + xgb_weight * y_test_pred_xgb
#
#     # 评估训练集和测试集的模型性能
#     train_mse, train_rmse, train_mae, train_r2 = evaluate_model_performance(y_train, y_train_pred_weighted)
#     test_mse, test_rmse, test_mae, test_r2 = evaluate_model_performance(y_test, y_test_pred_weighted)
#
#     return y_test_pred_weighted, test_rmse  # 返回RMSE作为优化目标
#
# # 寻找最优的加权组合
# def find_optimal_weights_for_target(target_name, target, features, num_features=15):
#     best_rmse = float('inf')  # 初始值设为正无穷
#     best_weights = None
#     best_y_test_pred_weighted = None
#
#     # 使用交叉验证
#     kf = KFold(n_splits=5, shuffle=True, random_state=42)
#
#     # 在[0, 1]之间步长为0.1遍历权重
#     for rf_weight in np.arange(0, 1.1, 0.1):
#         xgb_weight = 1 - rf_weight
#         print(f"Finding optimal weights for target: {target_name} | RF Weight: {rf_weight:.2f} | XGB Weight: {xgb_weight:.2f}")
#
#         fold_rmse = []
#
#         for train_index, test_index in kf.split(features):
#             # 拆分数据集
#             X_train, X_test = features.iloc[train_index], features.iloc[test_index]
#             y_train, y_test = target.iloc[train_index], target.iloc[test_index]
#
#             # 预处理数据
#             X_train_transformed = preprocessor.fit_transform(X_train)
#             X_test_transformed = preprocessor.transform(X_test)
#
#             # 训练加权投票模型并获取性能
#             _, rmse = train_weighted_voting_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=rf_weight, xgb_weight=xgb_weight, num_features=num_features)
#             fold_rmse.append(rmse)
#
#         # 计算当前权重组合的平均RMSE
#         mean_rmse = np.mean(fold_rmse)
#
#         # 判断当前组合的RMSE是否优于当前最优结果
#         if mean_rmse < best_rmse:
#             best_rmse = mean_rmse
#             best_weights = (rf_weight, xgb_weight)
#             best_y_test_pred_weighted = _  # 返回最后一折的预测值
#
#     print(f"Best weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}, Mean RMSE = {best_rmse:.2f}")
#     return best_weights
#
# # 主函数：遍历每个目标（24h, 48h, 72h, 96h）并寻找最优权重
# for target_name, target in targets.items():
#     print(f"Processing target: {target_name}")
#     best_weights = find_optimal_weights_for_target(target_name, target, features, num_features=15)
#     print(f"Optimal weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}")



# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn.model_selection import train_test_split, KFold
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.pipeline import Pipeline
# from sklearn.impute import SimpleImputer
# from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
# from sklearn.ensemble import RandomForestRegressor
# import xgboost as xgb
# from sklearn.feature_selection import RFE
# import math
#
# # 读取数据
# file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
# data = pd.read_excel(file_path)
#
# # 丢弃目标变量中含有缺失值的行
# data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
#
# # 选择特征和目标变量
# features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
# targets = {
#     '24h': data['Amount_24'],
#     '48h': data['Amount_48h'],
#     '72h': data['Amount_72h'],
#     '96h': data['Amount_96h']
# }
#
# # 分离数值型和非数值型特征
# numeric_features = features.select_dtypes(include=['number']).columns
# categorical_features = features.select_dtypes(include=['object']).columns
#
# # 创建预处理管道
# preprocessor = ColumnTransformer(
#     transformers=[('num', Pipeline(steps=[('imputer', SimpleImputer(strategy='mean')),  # 填补数值特征中的缺失值
#                                           ('scaler', StandardScaler())]), numeric_features),
#                   ('cat', Pipeline(steps=[('imputer', SimpleImputer(strategy='most_frequent')),  # 填补分类特征中的缺失值
#                                           ('onehot', OneHotEncoder(handle_unknown='ignore'))]), categorical_features)
#                   ])
#
# # 评估模型性能指标
# def evaluate_model_performance(y_true, y_pred):
#     # 计算R²
#     r2 = r2_score(y_true, y_pred)
#     return r2
#
# # 函数：训练加权投票模型（RandomForest + XGBoost），评估模型性能并返回R²
# def train_weighted_voting_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=0.5, xgb_weight=0.5, num_features=None):
#     # 特征选择 - 使用RFE进行特征选择
#     if num_features is not None:
#         rfe_selector = RFE(estimator=RandomForestRegressor(random_state=42), n_features_to_select=num_features)
#         X_train_selected = rfe_selector.fit_transform(X_train_transformed, y_train)
#         X_test_selected = rfe_selector.transform(X_test_transformed)
#     else:
#         X_train_selected = X_train_transformed
#         X_test_selected = X_test_transformed
#
#     # 定义XGBoost和Random Forest模型
#     xgboost_model = xgb.XGBRegressor(random_state=42)
#     rf_model = RandomForestRegressor(random_state=42)
#
#     # 训练XGBoost模型
#     xgboost_model.fit(X_train_selected, y_train)
#
#     # 训练Random Forest模型
#     rf_model.fit(X_train_selected, y_train)
#
#     # 预测
#     y_train_pred_rf = rf_model.predict(X_train_selected)
#     y_test_pred_rf = rf_model.predict(X_test_selected)
#
#     y_train_pred_xgb = xgboost_model.predict(X_train_selected)
#     y_test_pred_xgb = xgboost_model.predict(X_test_selected)
#
#     # 加权投票合并预测结果
#     y_train_pred_weighted = rf_weight * y_train_pred_rf + xgb_weight * y_train_pred_xgb
#     y_test_pred_weighted = rf_weight * y_test_pred_rf + xgb_weight * y_test_pred_xgb
#
#     # 计算R²
#     train_r2 = evaluate_model_performance(y_train, y_train_pred_weighted)
#     test_r2 = evaluate_model_performance(y_test, y_test_pred_weighted)
#
#     return y_test_pred_weighted, test_r2  # 返回R²作为优化目标
#
# # 寻找最优的加权组合
# def find_optimal_weights_for_target(target_name, target, features, num_features=15):
#     best_r2 = -np.inf  # 初始值设为负无穷
#     best_weights = None
#     best_y_test_pred_weighted = None
#
#     # 使用交叉验证
#     kf = KFold(n_splits=15, shuffle=True, random_state=42)
#
#     # 在[0, 1]之间步长为0.1遍历权重
#     for rf_weight in np.arange(0, 1.1, 0.1):
#         xgb_weight = 1 - rf_weight
#         print(f"Finding optimal weights for target: {target_name} | RF Weight: {rf_weight:.2f} | XGB Weight: {xgb_weight:.2f}")
#
#         fold_r2 = []
#
#         for train_index, test_index in kf.split(features):
#             # 拆分数据集
#             X_train, X_test = features.iloc[train_index], features.iloc[test_index]
#             y_train, y_test = target.iloc[train_index], target.iloc[test_index]
#
#             # 预处理数据
#             X_train_transformed = preprocessor.fit_transform(X_train)
#             X_test_transformed = preprocessor.transform(X_test)
#
#             # 训练加权投票模型并获取R²
#             _, r2 = train_weighted_voting_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=rf_weight, xgb_weight=xgb_weight, num_features=num_features)
#             fold_r2.append(r2)
#
#         # 计算当前权重组合的平均R²
#         mean_r2 = np.mean(fold_r2)
#
#         # 判断当前组合的R²是否大于0且优于当前最优结果
#         if mean_r2 > 0 and mean_r2 > best_r2:
#             best_r2 = mean_r2
#             best_weights = (rf_weight, xgb_weight)
#             best_y_test_pred_weighted = _  # 返回最后一折的预测值
#
#     if best_weights is not None:
#         print(f"Best weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}, Mean R² = {best_r2:.2f}")
#     else:
#         print(f"No valid weights found for {target_name} with R² > 0.")
#
#     return best_weights
#
# # 目标和特征数配置
# target_feature_config = {
#     '24h': 15,
#     '48h': 10,
#     '72h': 15,
#     '96h': 15
# }
#
# # 主函数：遍历每个目标（24h, 48h, 72h, 96h）并寻找最优权重
# for target_name, target in targets.items():
#     print(f"Processing target: {target_name}")
#     num_features = target_feature_config.get(target_name, 15)  # 获取对应目标的特征数量
#     best_weights = find_optimal_weights_for_target(target_name, target, features, num_features=num_features)
#     if best_weights is not None:
#         print(f"Optimal weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}")
#     else:
#         print(f"No valid optimal weights found for {target_name}.")


# R2  Blending模型：在 train_blending_model 中，将 RandomForest 和 XGBoost 的预测值进行加权合成，而不是用元学习器进行学习。
# 寻找最优权重：通过交叉验证 (KFold)，为每个目标变量（如 24h, 48h, 72h, 96h）寻找最佳的加权组合（rf_weight 和 xgb_weight）。
# 加权平均：通过加权平均方法将两个模型的预测结果结合起来。

# import pandas as pd
# import numpy as np
# import math
# from sklearn.model_selection import KFold
# from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
# from sklearn.ensemble import RandomForestRegressor
# import xgboost as xgb
# from sklearn.preprocessing import StandardScaler, OneHotEncoder
# from sklearn.compose import ColumnTransformer
# from sklearn.impute import SimpleImputer
# from sklearn.pipeline import Pipeline
#
# # 读取数据
# file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
# data = pd.read_excel(file_path)
#
# # 丢弃目标变量中含有缺失值的行
# data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
#
# # 选择特征和目标变量
# features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
# targets = {
#     '24h': data['Amount_24'],
#     '48h': data['Amount_48h'],
#     '72h': data['Amount_72h'],
#     '96h': data['Amount_96h']
# }
#
# # 创建预处理管道
# numeric_features = features.select_dtypes(include=['number']).columns
# categorical_features = features.select_dtypes(include=['object']).columns
#
# preprocessor = ColumnTransformer(
#     transformers=[('num', Pipeline(steps=[('imputer', SimpleImputer(strategy='mean')),  # 填补数值特征中的缺失值
#                                           ('scaler', StandardScaler())]), numeric_features),
#                   ('cat', Pipeline(steps=[('imputer', SimpleImputer(strategy='most_frequent')),  # 填补分类特征中的缺失值
#                                           ('onehot', OneHotEncoder(handle_unknown='ignore'))]), categorical_features)
#                   ])
#
# # 评估模型性能指标
# def evaluate_model_performance(y_true, y_pred):
#     mse = mean_squared_error(y_true, y_pred)
#     rmse = math.sqrt(mse)
#     mae = mean_absolute_error(y_true, y_pred)
#     r2 = r2_score(y_true, y_pred)
#     return mse, rmse, mae, r2
#
# # 函数：训练Blending模型（RandomForest + XGBoost），评估模型性能并可视化
# def train_blending_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=0.5, xgb_weight=0.5, num_features=None):
#     # 特征选择 - 使用RFE进行特征选择
#     if num_features is not None:
#         from sklearn.feature_selection import RFE
#         rfe_selector = RFE(estimator=RandomForestRegressor(random_state=42), n_features_to_select=num_features)
#         X_train_selected = rfe_selector.fit_transform(X_train_transformed, y_train)
#         X_test_selected = rfe_selector.transform(X_test_transformed)
#     else:
#         X_train_selected = X_train_transformed
#         X_test_selected = X_test_transformed
#
#     # 定义XGBoost和Random Forest模型
#     xgboost_model = xgb.XGBRegressor(random_state=42)
#     rf_model = RandomForestRegressor(random_state=42)
#
#     # 训练XGBoost模型
#     xgboost_model.fit(X_train_selected, y_train)
#
#     # 训练Random Forest模型
#     rf_model.fit(X_train_selected, y_train)
#
#     # 预测
#     y_train_pred_rf = rf_model.predict(X_train_selected)
#     y_test_pred_rf = rf_model.predict(X_test_selected)
#
#     y_train_pred_xgb = xgboost_model.predict(X_train_selected)
#     y_test_pred_xgb = xgboost_model.predict(X_test_selected)
#
#     # Blending：加权平均合并预测结果
#     y_train_pred_blended = rf_weight * y_train_pred_rf + xgb_weight * y_train_pred_xgb
#     y_test_pred_blended = rf_weight * y_test_pred_rf + xgb_weight * y_test_pred_xgb
#
#     # 评估训练集和测试集的模型性能
#     train_mse, train_rmse, train_mae, train_r2 = evaluate_model_performance(y_train, y_train_pred_blended)
#     test_mse, test_rmse, test_mae, test_r2 = evaluate_model_performance(y_test, y_test_pred_blended)
#
#     return y_test_pred_blended, test_rmse  # 返回RMSE作为优化目标
#
# # 寻找最优的Blending组合
# def find_optimal_weights_for_target(target_name, target, features, num_features=15):
#     best_rmse = float('inf')  # 初始值设为正无穷
#     best_weights = None
#     best_y_test_pred_blended = None
#
#     # 使用交叉验证
#     kf = KFold(n_splits=5, shuffle=True, random_state=42)
#
#     # 在[0, 1]之间步长为0.1遍历权重
#     for rf_weight in np.arange(0, 1.1, 0.1):
#         xgb_weight = 1 - rf_weight
#         print(f"Finding optimal weights for target: {target_name} | RF Weight: {rf_weight:.2f} | XGB Weight: {xgb_weight:.2f}")
#
#         fold_rmse = []
#
#         for train_index, test_index in kf.split(features):
#             # 拆分数据集
#             X_train, X_test = features.iloc[train_index], features.iloc[test_index]
#             y_train, y_test = target.iloc[train_index], target.iloc[test_index]
#
#             # 预处理数据
#             X_train_transformed = preprocessor.fit_transform(X_train)
#             X_test_transformed = preprocessor.transform(X_test)
#
#             # 训练Blending模型并获取性能
#             _, rmse = train_blending_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=rf_weight, xgb_weight=xgb_weight, num_features=num_features)
#             fold_rmse.append(rmse)
#
#         # 计算当前权重组合的平均RMSE
#         mean_rmse = np.mean(fold_rmse)
#
#         # 判断当前组合的RMSE是否优于当前最优结果
#         if mean_rmse < best_rmse:
#             best_rmse = mean_rmse
#             best_weights = (rf_weight, xgb_weight)
#             best_y_test_pred_blended = _  # 返回最后一折的预测值
#
#     print(f"Best weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}, Mean RMSE = {best_rmse:.2f}")
#     return best_weights
#
# # 主函数：遍历每个目标（24h, 48h, 72h, 96h）并寻找最优权重
# for target_name, target in targets.items():
#     print(f"Processing target: {target_name}")
#     best_weights = find_optimal_weights_for_target(target_name, target, features, num_features=15)
#     print(f"Optimal weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}")



import pandas as pd
import numpy as np
import math
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

# 读取数据
file_path = 'C:/Users/xyz/Desktop/Data_microalgae_1.xlsx'
data = pd.read_excel(file_path)

# 丢弃目标变量中含有缺失值的行
data = data.dropna(subset=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])

# 选择特征和目标变量
features = data.drop(columns=['Amount_24', 'Amount_48h', 'Amount_72h', 'Amount_96h'])
targets = {
    '24h': data['Amount_24'],
    '48h': data['Amount_48h'],
    '72h': data['Amount_72h'],
    '96h': data['Amount_96h']
}

# 创建预处理管道
numeric_features = features.select_dtypes(include=['number']).columns
categorical_features = features.select_dtypes(include=['object']).columns

preprocessor = ColumnTransformer(
    transformers=[('num', Pipeline(steps=[('imputer', SimpleImputer(strategy='mean')),  # 填补数值特征中的缺失值
                                          ('scaler', StandardScaler())]), numeric_features),
                  ('cat', Pipeline(steps=[('imputer', SimpleImputer(strategy='most_frequent')),  # 填补分类特征中的缺失值
                                          ('onehot', OneHotEncoder(handle_unknown='ignore'))]), categorical_features)
                  ])

# 评估模型性能指标
def evaluate_model_performance(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = math.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, rmse, mae, r2

# 函数：训练Blending模型（RandomForest + XGBoost），评估模型性能并可视化
def train_blending_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=0.5, xgb_weight=0.5, num_features=None):
    # 特征选择 - 使用RFE进行特征选择
    if num_features is not None:
        from sklearn.feature_selection import RFE
        rfe_selector = RFE(estimator=RandomForestRegressor(random_state=42), n_features_to_select=num_features)
        X_train_selected = rfe_selector.fit_transform(X_train_transformed, y_train)
        X_test_selected = rfe_selector.transform(X_test_transformed)
    else:
        X_train_selected = X_train_transformed
        X_test_selected = X_test_transformed

    # 定义XGBoost和Random Forest模型
    xgboost_model = xgb.XGBRegressor(random_state=42)
    rf_model = RandomForestRegressor(random_state=42)

    # 训练XGBoost模型
    xgboost_model.fit(X_train_selected, y_train)

    # 训练Random Forest模型
    rf_model.fit(X_train_selected, y_train)

    # 预测
    y_train_pred_rf = rf_model.predict(X_train_selected)
    y_test_pred_rf = rf_model.predict(X_test_selected)

    y_train_pred_xgb = xgboost_model.predict(X_train_selected)
    y_test_pred_xgb = xgboost_model.predict(X_test_selected)

    # Blending：加权平均合并预测结果
    y_train_pred_blended = rf_weight * y_train_pred_rf + xgb_weight * y_train_pred_xgb
    y_test_pred_blended = rf_weight * y_test_pred_rf + xgb_weight * y_test_pred_xgb

    # 评估训练集和测试集的模型性能
    train_mse, train_rmse, train_mae, train_r2 = evaluate_model_performance(y_train, y_train_pred_blended)
    test_mse, test_rmse, test_mae, test_r2 = evaluate_model_performance(y_test, y_test_pred_blended)

    return y_test_pred_blended, test_rmse  # 返回RMSE作为优化目标

# 寻找最优的Blending组合
def find_optimal_weights_for_target(target_name, target, features, num_features=15):
    best_rmse = float('inf')  # 初始值设为正无穷
    best_weights = None
    best_y_test_pred_blended = None

    # 使用交叉验证
    kf = KFold(n_splits=10, shuffle=True, random_state=42)

    # 在[0, 1]之间步长为0.1遍历权重
    for rf_weight in np.arange(0, 1.1, 0.1):
        xgb_weight = 1 - rf_weight
        print(f"Finding optimal weights for target: {target_name} | RF Weight: {rf_weight:.2f} | XGB Weight: {xgb_weight:.2f}")

        fold_rmse = []

        for train_index, test_index in kf.split(features):
            # 拆分数据集
            X_train, X_test = features.iloc[train_index], features.iloc[test_index]
            y_train, y_test = target.iloc[train_index], target.iloc[test_index]

            # 预处理数据
            X_train_transformed = preprocessor.fit_transform(X_train)
            X_test_transformed = preprocessor.transform(X_test)

            # 训练Blending模型并获取性能
            _, rmse = train_blending_model(X_train_transformed, X_test_transformed, y_train, y_test, rf_weight=rf_weight, xgb_weight=xgb_weight, num_features=num_features)
            fold_rmse.append(rmse)

        # 计算当前权重组合的平均RMSE
        mean_rmse = np.mean(fold_rmse)

        # 判断当前组合的RMSE是否优于当前最优结果
        if mean_rmse < best_rmse:
            best_rmse = mean_rmse
            best_weights = (rf_weight, xgb_weight)
            best_y_test_pred_blended = _  # 返回最后一折的预测值

    print(f"Best weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}, Mean RMSE = {best_rmse:.2f}")
    return best_weights

# 主函数：遍历每个目标（24h, 48h, 72h, 96h）并寻找最优权重
for target_name, target in targets.items():
    print(f"Processing target: {target_name}")
    best_weights = find_optimal_weights_for_target(target_name, target, features, num_features=15)
    print(f"Optimal weights for {target_name}: RF Weight = {best_weights[0]:.2f}, XGB Weight = {best_weights[1]:.2f}")
